
from dyna_cpp import QD_D3plot

class D3plot(QD_D3plot):
    pass
#    def __init__(self,*args,**kwargs):
#        super(D3plot, self).__init__()
