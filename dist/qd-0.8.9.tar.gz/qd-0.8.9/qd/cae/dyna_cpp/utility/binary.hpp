
#ifndef BINARY_HPP
#define BINARY_HPP

namespace qd {} // namespace:qd

#endif