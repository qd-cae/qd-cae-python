
Keyword
^^^^^^^

This class is used for almost all Keywords. It simply saves and manipulates the lines of the Keyword smartly and also proides multiple means of manipulation. For reading these keywords, please enable the argument `read_keywords` in the KeyFile constructor.

.. autoclass:: qd.cae.dyna.Keyword
    :members:
    :inherited-members:

    .. automethod:: __init__

    .. automethod:: qd.cae.dyna.Keyword.__setitem__

    .. automethod:: qd.cae.dyna.Keyword.__getitem__

    .. automethod:: qd.cae.dyna.Keyword.__repr__

    .. automethod:: qd.cae.dyna.Keyword.__iter__

    .. automethod:: qd.cae.dyna.Keyword.__str__