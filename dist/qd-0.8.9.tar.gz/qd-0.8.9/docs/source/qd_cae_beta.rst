
qd.cae.beta
===========

Module for CAE stuff related to software from Beta CAE Systems.

MetaCommunicator
----------------

.. autoclass:: qd.cae.beta.MetaCommunicator
    :members:
    :special-members:

    .. automethod:: __init__