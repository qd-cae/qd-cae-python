
IncludePathKeyword
^^^^^^^^^^^^^^^^^^

This class is used to manage include directories of the KeyFile. When loading includes, all of the specified directories will be searched for the includes.

.. autoclass:: qd.cae.dyna.IncludePathKeyword
    :members:
