
D3plot
------

Ressources:
    - `youtube tutorial`_
    - `3d html example`_

.. _youtube tutorial: https://www.youtube.com/watch?v=w8qIzqPJ4VY
.. _3d html example: ./d3plot_3d_html_example.html

---------------

.. autoclass:: qd.cae.dyna.D3plot
    :members:
    :inherited-members:

    .. automethod:: __init__
    