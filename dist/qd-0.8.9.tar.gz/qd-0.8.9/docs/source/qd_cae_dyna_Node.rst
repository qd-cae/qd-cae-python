
Node
----

Class for nodal data.

.. autoclass:: qd.cae.dyna.Node
    :members: