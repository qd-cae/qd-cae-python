
qd.numerics
===========

This module contains additional numerical functions.


sampling
--------

This module contains functions related to sampling and DOEs.

.. automodule:: qd.numerics.sampling
   :members: