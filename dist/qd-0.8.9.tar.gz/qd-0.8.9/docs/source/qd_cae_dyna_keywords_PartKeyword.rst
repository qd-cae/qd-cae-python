
PartKeyword
^^^^^^^^^^^

This class is used to manage parts of the KeyFile.

.. autoclass:: qd.cae.dyna.PartKeyword
    :members:
