
Element
-------

Class for handling element related data.

.. autoclass:: qd.cae.dyna.Element
    :members: