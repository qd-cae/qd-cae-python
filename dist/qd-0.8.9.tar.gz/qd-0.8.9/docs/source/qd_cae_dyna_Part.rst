
Part
----

Class for handling Part data.

.. autoclass:: qd.cae.dyna.QD_Part
    :members:
    :inherited-members: