
Binout
------

There is a `YOUTUBE TUTORIAL`_ for this class available:

.. _YOUTUBE TUTORIAL: https://www.youtube.com/watch?v=P96Vkuvg02w&t=2s

.. autoclass:: qd.cae.dyna.Binout
    :members:

    .. automethod:: __init__