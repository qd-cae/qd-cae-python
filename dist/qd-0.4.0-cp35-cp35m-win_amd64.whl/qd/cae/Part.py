
class Part(QD_Part):

    def __init__(self, *args, **kwargs):
        super(Part, self).__init__(*args, **kwargs)