
from .dyna_cpp import QD_D3plot

class D3plot(QD_D3plot):
    '''
    Class for reading a D3plot. A D3plot is a binary result file 
    written from LS-Dyna and contains the simulation mesh, as well
    as the time step data.
    '''

    def __init__(self, *args, **kwargs):
        '''Constructor for a D3plot.

        Note:
            If LS-Dyna writes multiple files (one for each timestep),
            give the filepath to the first file. The library finds all
            other files.
            Please read state information with the read_states flag 
            in the constructor or with the member function.

        Args:
            str filepath : path to the d3plot
            bool use_femzip : use femzip for decompression
            str/list(str) read_states : read state information,
                                        see the function read_states

        Returns:
            D3plot d3plot : instance

        '''
        super(QD_D3plot, self).__init__(*args, **kwargs)