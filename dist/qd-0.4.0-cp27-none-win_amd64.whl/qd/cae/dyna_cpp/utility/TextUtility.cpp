
#include "TextUtility.hpp"
#include <algorithm>
#include <functional>
#include <cctype>
#include <locale>
